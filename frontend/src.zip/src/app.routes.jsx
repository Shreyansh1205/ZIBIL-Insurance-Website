import {
  createBrowserRouter,
  Navigate,
} from "react-router";

import Homepage from "./pages/Homepage";
import Solutionpage from "./pages/Solutionpage";
import Contactpage from "./pages/Contactpage";
import Aboutpage from "./pages/Aboutpage";
import Privacypage from "./pages/Privacypage";
import Careerpage from "./pages/Careerpage";

import PortalSelection from "./portal/PortalSelection";
import PortalLogin from "./portal/PortalLogin";
import CustomerDashboard from "./portal/CustomerDashboard";
import CorporateDashboard from "./portal/CorporateDashboard";
import PortalModulePage from "./portal/PortalModulePage";

import { usePortalAuth } from "./contexts/portalAuth.context";


function ProtectedRoute({
  type,
  children,
}) {
  const {
    user,
  } = usePortalAuth();

  if (!user) {
    return (
      <Navigate
        to={
          type === "corporate"
            ? "/portal/corporate/login"
            : "/portal/customer/login"
        }
        replace
      />
    );
  }

  if (
    type === "corporate" &&
    user.role !== "corporate_employee"
  ) {
    return (
      <Navigate
        to="/portal/corporate/login"
        replace
      />
    );
  }

  if (
    type === "customer" &&
    user.role !== "customer"
  ) {
    return (
      <Navigate
        to="/portal/customer/login"
        replace
      />
    );
  }

  return children;
}


export const router =
  createBrowserRouter([

    /* =====================================================
       PUBLIC WEBSITE
    ===================================================== */

    {
      path: "/",
      element: <Homepage />,
    },

    {
      path: "/solutions",
      element: <Solutionpage />,
    },

    {
      path: "/contact",
      element: <Contactpage />,
    },

    {
      path: "/about",
      element: <Aboutpage />,
    },

    {
      path: "/privacy",
      element: <Privacypage />,
    },

    {
      path: "/career",
      element: <Careerpage />,
    },


    /* =====================================================
       PORTAL ENTRY
    ===================================================== */

    {
      path: "/login",
      element: <PortalSelection />,
    },

    {
      path: "/portal",
      element: <PortalSelection />,
    },


    /* =====================================================
       CUSTOMER LOGIN
    ===================================================== */

    {
      path: "/portal/customer/login",
      element: (
        <PortalLogin
          type="customer"
        />
      ),
    },


    /* =====================================================
       CORPORATE LOGIN
    ===================================================== */

    {
      path: "/portal/corporate/login",
      element: (
        <PortalLogin
          type="corporate"
        />
      ),
    },


    /* =====================================================
       CUSTOMER DASHBOARD
    ===================================================== */

    {
      path: "/customer/dashboard",
      element: (
        <ProtectedRoute
          type="customer"
        >
          <CustomerDashboard />
        </ProtectedRoute>
      ),
    },


    {
      path: "/customer/:module",
      element: (
        <ProtectedRoute
          type="customer"
        >
          <PortalModulePage
            type="customer"
          />
        </ProtectedRoute>
      ),
    },


    /* =====================================================
       CORPORATE DASHBOARD
    ===================================================== */

    {
      path: "/corporate/dashboard",
      element: (
        <ProtectedRoute
          type="corporate"
        >
          <CorporateDashboard />
        </ProtectedRoute>
      ),
    },


    {
      path: "/corporate/:module",
      element: (
        <ProtectedRoute
          type="corporate"
        >
          <PortalModulePage
            type="corporate"
          />
        </ProtectedRoute>
      ),
    },


    /* =====================================================
       FALLBACK
    ===================================================== */

    {
      path: "*",
      element: (
        <Navigate
          to="/"
          replace
        />
      ),
    },

  ]);